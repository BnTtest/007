<?php

$onGroupPowers = function (array $array) {
};
