<?php

$onBlast = function (array $array) {
};
