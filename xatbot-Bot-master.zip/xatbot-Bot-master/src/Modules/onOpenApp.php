<?php

$onOpenApp = function (int $who, int $app) {
};
