<?php

$onOldMessage = function (int $who, string $message) {
};
