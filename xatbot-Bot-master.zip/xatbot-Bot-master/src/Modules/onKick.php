<?php

$onKick = function (array $array) {

    //<k i="32758" d="1205438012" />
};
